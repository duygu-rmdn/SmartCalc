﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zadaca1
{
    public class StoreManager
    {
        private List<Product> products;
        public StoreManager()
        {
            products = new List<Product>();
        }
        public List<Product> Products { get => products; set => products = value; }

        public void AddProduct(Product product) 
        {
            products.Add(product);
        }

        public Product GetTheMostExpensiveProduct()
        {
            decimal max = products.Select(x => x.Price).Max();
            Product exp = new Product();
            foreach (var prod in products)
            {
                if (prod.Price == max)
                {
                    exp.Name = prod.Name;
                    exp.Price = prod.Price;
                    exp.Quantity = prod.Quantity;
                }
            }
            return exp;
        }
    }
}
