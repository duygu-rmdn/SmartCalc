﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zadaca1
{
    public class Product
    {
        private string name; 
        private int quantity; 
        private decimal price;
        public Product()
        {

        }
        public Product(string name, int quantity, decimal price)
        {
            this.Name = name;
            this.Quantity = quantity;
            this.Price = price;
        }
        public string Name { get => name; set => name = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public decimal Price { get => price; set => price = value; }

        public override string ToString()
        {
            return $"Product: {this.Name}, Quantity: {this.Quantity}, Price {this.Price} leva";
        }
    }
}
