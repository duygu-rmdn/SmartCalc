﻿using System;

namespace zadaca1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Product pr = new Product();
            pr.Name = "Pencils";
            pr.Price = 25.25m;
            pr.Quantity = 50;
            Console.WriteLine(pr.ToString());
            Product pr2 = new Product();
            pr2.Name = "Paints";
            pr2.Price = 30.25m;
            pr2.Quantity = 50;
            Console.WriteLine(pr2.ToString());
            Product pr3 = new Product("Pen", 55, 100.50m);

            StoreManager st = new StoreManager();
            st.AddProduct(pr);
            st.AddProduct(pr2);
            st.AddProduct(pr3);

            Product result = st.GetTheMostExpensiveProduct();

            Console.WriteLine("Info product max price");
            Console.WriteLine(result.ToString());

        }
    }
}
